# Moldura Karina Paiva 1022

Página Next.js pronta para publicar na Vercel.

## Rodar localmente

```bash
npm install
npm run dev
```

Abra http://localhost:3000

## Publicar na Vercel

1. Crie um repositório no GitHub.
2. Envie todos os arquivos desta pasta.
3. Na Vercel, importe o repositório.
4. Framework: Next.js (detectado automaticamente).
5. Deploy.

A moldura está em `public/moldura.png`. A página usa Canvas para colocar a foto do usuário atrás da moldura e permitir arrastar, aplicar zoom e baixar a imagem final em PNG.
